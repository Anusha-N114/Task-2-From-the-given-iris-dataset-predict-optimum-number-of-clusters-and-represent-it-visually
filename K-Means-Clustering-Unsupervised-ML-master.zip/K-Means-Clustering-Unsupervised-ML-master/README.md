# K-Means-Clustering-Unsupervised-ML

** Project done during the Data Science & Analytics Internship at The Sparks Foundation **

## **Task 2 - K-Means Clustering - Unsupervised Machine Learning**
Task: From the given ‘Iris’ dataset, predict the optimum number of clusters and represent it visually. 

* Libraries Used: Scikit Learn, Pandas, Numpy
* Dataset: Iris Dataset

* Complete Video Link: YouTube: https://youtu.be/i6aZqXEPyb0

**By- Satyam Roy**

